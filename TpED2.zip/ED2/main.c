#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "gerador.h"
#include "acesso.h"
#include "arvoreb.h"
#include "arvoreStar.h"
#include "arvorebin.h"

int main(int argc, char *argv[]){

    int metodo, qtd, situacao, p, compara_insescao = 0, compara_busca = 0;
    Dados reg_arq, x;
    //int *imprime = 0;
    Apontador arvore;
    FILE *registros;

    TipoChave c;
    TipoRegistro r;
    TipoApontador arvoreStar;

    printf("\t1 - acesso sequencial indexado\n\t2 - arvore binaria de pesquisa adequada a memoria externa\n\t3 - arvore B\n\t4 - arvore B*\n");
    scanf("%d", &metodo);
    printf("\n");
    printf("quantidade de registros do arquivo: ");
    scanf("%d", &qtd);
    printf("\n");
    printf("\t1 - arquivo ordenado ascendentemente\n\t2 - arquivo ordenado descendentemente\n\t3 - arquivo desordenado aleatoriamente\n");
    scanf("%d", &situacao);
    printf("\n");
    printf("chave de pesquisa: ");
    scanf("%d", &x.chave);
    printf("\n");
    printf("\t1 - imprime os registros\n\t2 - nao imprime os registros\n");
    scanf("%d", &p);

    if(situacao == 1){
        arqOrdenado(qtd);
    }
    else if(situacao == 2){
        arqInverso(qtd);
    }  
    else if(situacao == 3){
        arqRand(qtd);
    }

    switch (metodo){
    case 1:
        
        registros = fopen("registros1.bin","rb");  
        
        if(!pesquisa(x.chave, registros,qtd)){
            printf("Busca mau sucedida.\n");
        }
        else{
            printf("Chave localizada.\n");
        }
        fclose(registros);
        break;
    case 2:
        clock_t inicio = clock();
        int comparaBin = arvoreBin("registros1.bin");
        if(comparaBin == 0){
            printf("Falha ao abrir arquivo\n");
        }
        else if(comparaBin == -1){
            printf("A chave não foi encontrada\n");
        }
        else{
            printf("Chave Localizada\nComparacoes: %d\n", arvoreBin);
            clock_t fim = clock();
            printf("\tTempo de execucao (em segundos): %.4f\n", (double)(fim - inicio) / CLOCKS_PER_SEC);
        }
        break;
    case 3:
        if(situacao == 1 || situacao == 2 || situacao == 3){
            clock_t inicio = clock();
            registros = fopen("registros1.bin","rb");
            if(registros == NULL){
                printf("falha ao abrir o arquivo\n");
                return 0;
            }
            arvoreB_Cria(&arvore);
            
            for (int i = 0; i < qtd; i++){
                fread(&reg_arq, sizeof(Dados), 1, registros);
                arvoreB_Insere(reg_arq, &arvore, &compara_insescao);
            }
            fclose(registros);

            if (arvoreB_Busca(&x, arvore, &compara_busca)){
                clock_t fim = clock();
                printf("\tA chave foi encontrada!\n");
                //quantidade de comparacoes entre as chaves durante a criação da arvore
                printf("\tComparacoes para insercao: %d\n", compara_insescao);
                //quantidade de comparacoes entre as chaves durante a busca
                printf("\tComparacoes na busca: %d\n", compara_busca);
                // mede o tempo de execucao do programa do momento da criação da arvore ate a finalizacao da busca
                printf("\tTempo de execucao (em segundos): %.4f\n", (double)(fim - inicio) / CLOCKS_PER_SEC);
                printf("\n\n");
                
                if(p == 1){
                    //imprime os dados correspondentes a chave de X usada na busca
                    printf("\tChave: %d\n\n", x.chave);
                    printf("\tDado 1: %ld\n\n", x.dado1);
                    printf("\tDado 2: %s\n\n", x.dado2);
                    printf("\tDado 3: %s\n\n", x.dado3);
                }
            }
            else printf("a chave nao foi encontrada!\n");
        }
        break;
    case 4:
        registros = fopen("registros1.bin","rb");
        if(registros == NULL){
            printf("falha ao abrir o arquivo\n");
            return 0;
        }
        criaStar(&arvoreStar);
        for (int i = 0; i < 20; i++){
            fread(&c, sizeof(TipoChave), 1, registros);
            fseek(registros,sizeof(TipoRegistro)-4,SEEK_CUR);
            insereStar(c,&arvoreStar);
        }
        
        fclose(registros);
        //pesquisaStar(&r,&arvoreStar);

        break;
    }
    
    return 0;
}
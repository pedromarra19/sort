#ifndef ACESSO_H
#define ACESSO_H

#include <stdio.h>
#include <stdlib.h>

#define CAD_D2 500
#define CAD_D3 3000

typedef struct dados Dados;

int pesquisa(int chave, FILE *arq, int qtd);

#endif
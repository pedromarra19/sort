void arvoreB_Insere(Dados reg, Apontador *ap){
    
    short cresceu;
    Dados regRetorno;
    Pagina *apRetorno, *apTemp;

    arvoreB_Ins(reg, *ap, &cresceu, &regRetorno, &apRetorno);

    if(cresceu){
        apTemp = (Pagina*) malloc(sizeof(Pagina));
        apTemp->n = 1;
        apTemp->r[0] = regRetorno;
        apTemp->p[1] = apRetorno;
        apTemp->p[0] = *ap;
        *ap = apTemp;
    }
}

void arvoreB_Ins(Dados reg, Apontador ap, short *cresceu, Dados *regRetorno, Apontador *apRetorno){
    long i = 1;
    long j;
    Apontador apTemp;

    if(ap == NULL){
        *cresceu = 1;
        *regRetorno = reg;
        *apRetorno = NULL;
        return;
    }

    while (i < ap->n && reg.chave > ap->r[i - 1].chave){
        i++;
    }
    
    if(reg.chave == ap->r[i - 1].chave){
        *cresceu = 0;
        return;
    }

    if (reg.chave < ap->r[i - 1].chave){
        i--;
    }

    arvoreB_Ins(reg, ap->p[i], cresceu, regRetorno, apRetorno);

    if (!*cresceu){
        return;
    }
    
    if (ap->n < M * 2){
        arvoreB_InsereNaPagina(ap, *regRetorno, *apRetorno);
        *cresceu = 0;
        return;
    }
    
    apTemp = (Apontador) malloc(sizeof(Pagina));
    apTemp->n = 0;
    apTemp->p[0] = NULL;

    if(i < M + 1){
        arvoreB_InsereNaPagina(apTemp, ap->r[2 * M - 1], ap->p[2 * M]);
        ap->n--;
        arvoreB_InsereNaPagina(ap, *regRetorno, *apRetorno);
    }
    else arvoreB_InsereNaPagina(apTemp, *regRetorno, *apRetorno);

    for (j = M + 2; j < 2 * M; j++){
        arvoreB_InsereNaPagina(ap, ap->r[j - 1], ap->p[j]);
    }
    
    ap->n = M;
    apTemp->p[0] = ap->p[M + 1];
    *regRetorno = ap->r[M];
    *apRetorno = apTemp;
}

void arvoreB_InsereNaPagina(Apontador ap, Dados reg, Apontador apDir){
    short semPosi;
    int k;

    k = ap->n;
    semPosi = (k > 0);

    while (semPosi){
        if(reg.chave >= ap->r[k - 1].chave){
            semPosi = 0;
            break;
        }

        ap->r[k] = ap->r[k - 1];
        ap->p[k + 1] = ap->p[k];
        k--;

        if(k < 1){
            semPosi = 0;
        }
    }

    ap->r[k] = reg;
    ap->p[k + 1] =apDir;
    ap->n++;
}
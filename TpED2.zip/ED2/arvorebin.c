#include "arvorebin.h"


struct dado{
    int chave;
    long int dado1;
    char dado2[CAD_D2];
    char dado3[CAD_D3];
};
int arvoreBin(char *nomeArq){

    FILE *arq = fopen(nomeArq, "rb");//caso de erro no arquivo
    if(arq == NULL){
        return 0;
    }
    else{
        int n, verifica = 0, aux, aux2 = 0, comparacoes = 0;
        int chave, confere, tamanho;
        fread(&confere, sizeof(int), 1, arq);//conferindo se o arquivo é ordenado descendente ou ascendentemente
        if(confere == 1){//caso o arquivo seja ordenado ascendentemente
        //verificando quantidade de chaves do arquivo:
            fseek(arq, 0, SEEK_END);
            fseek(arq, ftell(arq) - sizeof(Dado), SEEK_SET);
            fread(&tamanho, sizeof(int), 1, arq);
            printf("tamanho: %d\n", tamanho);
            aux = tamanho/2;
            if(tamanho % 2 == 1){      //conferindo se eh numero impar, para que na hora da divisão por 
                tamanho = tamanho + 1; //2 não pegue o numero de baixo
            }
            tamanho = tamanho/2;
            printf("numero: ");//pegando item a ser pesquisado
            scanf("%d", &n);

            while(verifica != 1){
                if(tamanho % 2 == 1){
                    tamanho = tamanho + 1;
                }
                tamanho = tamanho / 2;//guardando o tamanho do limpo a ser analisado
                if(tamanho == 0){
                    comparacoes = -1;
                    break;
                }
                fseek(arq, aux * sizeof(Dado), SEEK_SET);
                fread(&chave, sizeof(int), 1, arq);//lendo a chave do arquivo
                if(chave == n){
                    verifica = 1;//caso encontrar a chave
                    printf("Comparacoes: %d\n", comparacoes);
                }
                else if(tamanho == 0){//se taamnho igualar a 0 significa que a chave nao foi encontrada
                    comparacoes = -1;
                    break;
                }
                //caso nao seja a chave certa:
                else if(chave > n){
                    if((aux - aux2) % 2 == 1){
                        aux = aux + 1;
                    }
                    aux = (aux - aux2)/2 + aux2;
                    comparacoes++;
                }
                else if(chave < n){
                    aux2 = aux;
                    aux = aux + tamanho;
                    comparacoes++;
                }
            }
        }
        else{//caso o arquivo seja ordenado descentemente
            tamanho = confere;
            printf("tamanho: %d\n", tamanho);
            aux = tamanho/2;
            if(tamanho % 2 == 1){      //conferindo se eh numero impar, para que na hora da divisão por 
                tamanho = tamanho + 1; //2 não pegue o numero de baixo
            }
            tamanho = tamanho/2;
            printf("numero: ");//pegando item a ser pesquisado
            scanf("%d", &n);

            while(verifica != 1){
                if(tamanho % 2 == 1){
                    tamanho = tamanho + 1;
                }
                tamanho = tamanho / 2;//guardando o tamanho do limpo a ser analisado 
                fseek(arq, aux * sizeof(Dado), SEEK_SET);
                fread(&chave, sizeof(int), 1, arq);//lendo a chave do arquivo
                if(chave == n){
                    verifica = 1;//caso encontrar a chave
                    printf("Comparacoes: %d\n", comparacoes);
                }
                else if(tamanho == 0){//caso nao tenha encontrado a chave
                    comparacoes = -1;
                    break;
                }
                //caso nao seja a chave certa:
                else if(chave < n){
                    if((aux - aux2) % 2 == 1){
                        aux = aux + 1;
                    }
                    aux = (aux - aux2)/2 + aux2;
                    comparacoes++;
                }
                else if(chave > n){
                    aux2 = aux;
                    aux = aux + tamanho;
                    comparacoes++;
                }
            }
        }
        return comparacoes;
    }

}
#ifndef ARVORESTAR_H
#define ARVORESTAR_H

#include <stdio.h>
#include <stdlib.h>

#define M 20
#define CAD_D2 500
#define CAD_D3 3000

typedef long TipoChave;

//vou armazenar os dados do arquivo
typedef struct TipoRegistro {
    TipoChave Chave;
    long int dado1;
    char dado2[CAD_D2];
    char dado3[CAD_D3];
} TipoRegistro;

typedef enum {Interna, Externa} TipoIntExt;

typedef struct TipoPagina* TipoApontador;

//union ira fazer a divisao da struct
//onde uma pagina interna sera UO e a externa U1
typedef struct TipoPagina{
    TipoIntExt Pt;//armazena se a pagina é interna ou externa
    union{
        struct{
            int ni;//quantidade de itens da minha pagina
            TipoChave ri[M*2];//vetor de chaves
            TipoApontador pi[(M*2) + 1];//vetor de apontador que ira apontar para outra pagina
        }UO;
        struct{
            int ne;
            TipoRegistro re[(M*2)*2];//vetor guardar registros
        }U1;
    }UU;
}TipoPagina;

void criaStar(TipoApontador *arvore);

void insereStar(TipoChave ch, TipoApontador *ap);

void insStar(TipoChave ch, TipoApontador ap, short *cresceu, TipoChave *chRetorno, TipoApontador *apRetorno);

void insereNaTipoPagina(TipoApontador ap, TipoChave ch, TipoApontador apDir);

int pesquisaStar(TipoRegistro *x, TipoApontador *Ap);
#endif
#include <stdlib.h>
#include <stdio.h>
#include "acesso.h"

struct dados{
    int chave;
    long int dado1;
    char dado2[CAD_D2];
    char dado3[CAD_D3];
};
int pesquisa(int chave, FILE *arq, int qtd){

    int chaveArq, aux;

    fread(&chaveArq, sizeof(chaveArq), 1, arq);

    //else{
        for(int i = 0; i < qtd;){
            fseek(arq,sizeof(Dados)-4,SEEK_CUR);
            fread(&aux, sizeof(aux), 1, arq);
            if(aux == chave){
               return 1;
            }
            i++;
        }
        return 0;
    //}
}
#ifndef ARVOREB_H
#define ARVOREB_H

#define CAD_DADOS2 500 //tamanho da cadeia de caracteres do segundo dado da struct Dados
#define CAD_DADOS3 3000 //tamanho da cadeia de caracteres do terceiro dado da struct Dados
#define M 20 //ordem da arvore
#define MM  (M * 2)
#define FALSE 0
#define TRUE  1

typedef int Chave;
typedef struct dados{
    Chave chave;
    long int dado1;
    char dado2[CAD_DADOS2];
    char dado3[CAD_DADOS3];
}Dados;

typedef struct pagina* Apontador;
typedef struct pagina{
    int n; //quantidade de elementos em uma pagina
    Dados r[2 * M];
    Apontador p[2 * M + 1];
}Pagina;

//cria uma arvore vazia 
void arvoreB_Cria(Apontador *arvore);

//realiza a busca na arvore
int arvoreB_Busca(Dados *x, Apontador ap, int *comparacoes);

void arvoreB_Insere(Dados Reg, Apontador *Ap, int *comparacoes);

//responsavel por controlar todo o processo de insercao dentro da arvore
void arvoreB_Ins(Dados Reg, Apontador Ap, short *Cresceu, Dados *RegRetorno,  Apontador *ApRetorno, int *comparacoes);

/*verifica se a pagina pode ou não receber outra chave. se puder, ela insere o item na pagina,
caso contrario, ela faz as devidas operaçoes para a insercao da chave na arvore*/
void arvoreB_InsereNaPagina(Apontador Ap, Dados Reg, Apontador ApDir, int *comparacoes); 

#endif
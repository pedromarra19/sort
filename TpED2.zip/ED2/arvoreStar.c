#include <stdlib.h>
#include <stdio.h>
#include "arvoreStar.h"

void criaStar(TipoApontador *arvore){
    *arvore = NULL;
}
void insereStar(TipoChave ch, TipoApontador *ap){
    
    short cresceu;
    TipoChave regChave;
    TipoPagina *apRetorno, *apTemp;

    insStar(ch, *ap, &cresceu, &regChave, &apRetorno);

    if(cresceu){
        apTemp = (TipoPagina*) malloc(sizeof(TipoPagina));
        apTemp->UU.UO.ni = 1;
        apTemp->UU.UO.ri[0] = regChave;
        apTemp->UU.UO.pi[1] = apRetorno;
        apTemp->UU.UO.pi[0] = *ap;
        *ap = apTemp;
    }
}
void insStar(TipoChave ch, TipoApontador ap, short *cresceu, TipoChave *chRetorno, TipoApontador *apRetorno){
    long i = 1;
    long j;
    TipoApontador apTemp;

    if(ap == NULL){
        *cresceu = 1;
        *chRetorno = ch;
        *apRetorno = NULL;
        return;
    }

    while (i < ap->UU.UO.ni && ch > ap->UU.UO.ri[i - 1]){
        i++;
    }
    
    if(ch == ap->UU.UO.ri[i - 1]){
        *cresceu = 0;
        return;
    }

    if (ch < ap->UU.UO.ri[i - 1]){
        i--;
    }

    insStar(ch, ap->UU.UO.pi[i], cresceu, chRetorno, apRetorno);

    if (!*cresceu){
        return;
    }
    
    if (ap->UU.UO.ni < M * 2){
        insereNaTipoPagina(ap, *chRetorno, *apRetorno);
        *cresceu = 0;
        return;
    }
    
    apTemp = (TipoApontador) malloc(sizeof(TipoPagina));
    apTemp->UU.UO.ni = 0;
    apTemp->UU.UO.pi[0] = NULL;

    if(i < M + 1){
        insereNaTipoPagina(apTemp, ap->UU.UO.ri[2 * M - 1], ap->UU.UO.pi[2 * M]);
        ap->UU.UO.ni--;
        insereNaTipoPagina(ap, *chRetorno, *apRetorno);
    }
    else insereNaTipoPagina(apTemp, *chRetorno, *apRetorno);

    for (j = M + 2; j < 2 * M; j++){
        insereNaTipoPagina(ap, ap->UU.UO.ri[j - 1], ap->UU.UO.pi[j]);
    }
    
    ap->UU.UO.ni = M;
    apTemp->UU.UO.pi[0] = ap->UU.UO.pi[M + 1];
    *chRetorno = ap->UU.UO.ri[M];
    *apRetorno = apTemp;
}
void insereNaTipoPagina(TipoApontador ap, TipoChave ch, TipoApontador apDir){
    short semPosi;
    int k;

    k = ap->UU.UO.ni;
    semPosi = (k > 0);

    while (semPosi){
        if(ch >= ap->UU.UO.ri[k - 1]){
            semPosi = 0;
            break;
        }

        ap->UU.UO.ri[k] = ap->UU.UO.ri[k - 1];
        ap->UU.UO.pi[k + 1] = ap->UU.UO.pi[k];
        k--;

        if(k < 1){
            semPosi = 0;
        }
    }

    ap->UU.UO.ri[k] = ch;
    ap->UU.UO.pi[k + 1] =apDir;
    ap->UU.UO.ni++;
}
int pesquisaStar(TipoRegistro *x, TipoApontador *Ap){

    int i;
    TipoApontador Pag;
    Pag = *Ap;
//se pt for interna faco a pesquisa usando os campos da pagina interna
    //if((*Ap)->Pt == Interna){
        i = 1;
//realizo uma pesquisa sequencial dentro da pagina
//realizo a analise pra ver quantos itens temos na pagina e se minha chave é maior que a chave da pagina
        while(i < Pag->UU.UO.ni && x->Chave > Pag->UU.UO.ri[i - 1])
            i++;

//de acordo com meu valor, eu direciono a pesquisa para a direita ou para a esquerda

        if(x->Chave < Pag->UU.UO.ri[i - 1])
            pesquisaStar(x, &Pag->UU.UO.pi[i - 1]);
        else
            pesquisaStar(x, &Pag->UU.UO.pi[i]);
        
        return;
    //}
//assim que localizar uma pagina externa a pesquisa sera direcionada a ela
    i = 1;
//faco novamente a pesquisa porem agora dentro de uma pagina externa
    while(i < Pag->UU.U1.ne && x->Chave > Pag->UU.U1.re[i - 1].Chave)
        i++;
//se a chave for igual retorno o registro por referencia
    if(x->Chave == Pag->UU.U1.re[i- 1].Chave){
        *x = Pag->UU.U1.re[i - 1];
        return 1;
    }
    else
        return 0;
}




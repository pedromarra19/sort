#include <stdio.h>
#include <stdlib.h>

#define TAM 2000
#define CAD_D2 500
#define CAD_D3 3000

typedef struct dado Dado;

int arvoreBin(char *nomeArq);
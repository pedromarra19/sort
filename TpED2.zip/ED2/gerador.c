#include "gerador.h"

struct d{
    int chave;
    long int dado1;
    char dado2[CAD_D2];
    char dado3[CAD_D3];
};

void arqOrdenado(int qtd){
    
    Componentes d;
    srand(time(NULL));
    FILE *arq = fopen("registros1.bin", "wb");
    for (int i = 0; i < qtd+1; i++)
    {
        d.chave = i;
        d.dado1 = rand() % 2147483647;

        for (int k = 0; k < CAD_D2; k++)
            d.dado2[k] = 'a' + (char)(rand() % 26);

        for (int j = 0; j < CAD_D3; j++)
            d.dado3[j] = '!' + (char)(rand() % 20);

        fwrite(&d, sizeof(d), 1, arq);
    }
    fclose(arq);
}
void arqInverso(int qtd){  
    Componentes d;
    srand(time(NULL));
    FILE *arq = fopen("registros1.bin", "wb");

    for (int i = qtd+1; i >= 0; i--){
       
        d.chave = i;
        d.dado1 = rand() % 2147483647;

        for (int k = 0; k < CAD_D2; k++)
            d.dado2[k] = 'a' + (char)(rand() % 26);

        for (int j = 0; j < CAD_D3; j++)
            d.dado3[j] = '!' + (char)(rand() % 20);

        fwrite(&d, sizeof(d), 1, arq);
    }
    fclose(arq);
}
void arqRand(int qtd){  
    Componentes d;
    srand(time(NULL));
    FILE *arq = fopen("registros1.bin", "wb");

    for (int i = qtd; i > 0; i--){
       
        d.chave = rand() % qtd;
        d.dado1 = rand() % 2147483647;

        for (int k = 0; k < CAD_D2; k++)
            d.dado2[k] = 'a' + (char)(rand() % 26);

        for (int j = 0; j < CAD_D3; j++)
            d.dado3[j] = '!' + (char)(rand() % 20);

        fwrite(&d, sizeof(d), 1, arq);
    }
    fclose(arq);
}
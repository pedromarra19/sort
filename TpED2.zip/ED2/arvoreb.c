#include <stdio.h>
#include <stdlib.h>
#include "arvoreb.h"

void arvoreB_Cria(Apontador *arvore){
    *arvore = NULL;
}

int arvoreB_Busca(Dados *x, Apontador ap, int *comparaco){
  int i = 1;

  //verifica se a arvore/pagina existe ou não
  if(ap == NULL){
    (*comparaco)++;
    return 0; //retorna 0 se a arvore/pagina não existe
  }

  /*caso a pagina exista, o programa entrara nesse loop e 
  fara uma busca sequncial na pagina atras da chave desejada*/

  /* enquanto i for menor que o tamanho da pagina e a chave desejada for maior que a chave atual,
  o loop incrementa +1 a variavel i para percorrer a pagina*/
  while (i < ap->n && x->chave > ap->r[i - 1].chave){
      i++;
      (*comparaco)++;
  }

  //verifica se é a chave desejada
  if(x->chave == ap->r[i - 1].chave){
      *x = ap->r[i - 1];
      (*comparaco)++;
      return 1; //se for a pagina desejada, a funcao retorna 1
  }

  if(x->chave < ap->r[i - 1].chave){
      arvoreB_Busca(x, ap->p[i - 1], comparaco);//vai para o filho a esquerda se a chave desejada for menor que a chave atual
  } else arvoreB_Busca(x, ap->p[i], comparaco);//vai para o filho da direita se a chave desejada for maior que a chave atual
  
}

/*recebe o registro que se deseja inserir, a arvore B na qual se deseja inserir esse registro
e uma variavel para contabilizar as comparaçoes*/
void arvoreB_Insere(Dados Reg, Apontador *Ap, int *comparacoes){

  /*A variavel Cresceu funciona como uma variavel do tipo bool, indica se a arvore vai crescer ou nao, 
  recebe 1 quando a divisao das paginas da arvore chega a raiz. 
  Tambem é responsavel por "informar" se ocorreu uma divisao de paginas*/
  short Cresceu;
  Dados RegRetorno;
  Pagina *ApRetorno, *ApTemp;

  arvoreB_Ins(Reg, *Ap, &Cresceu, &RegRetorno, &ApRetorno, comparacoes); // Chamando funcao insere auxiliar

  //se Cresceu recebe 1, quer dizer que é necessario a criação de uma nova pagina raiz
  if (Cresceu){
    ApTemp = (Pagina *)malloc(sizeof(Pagina)); // Criando nova raiz
    ApTemp->n = 1;  // Definindo que a nova raiz só terá um índice
    ApTemp->r[0] = RegRetorno; //o filho mais a esquerda recebe o item que se deseja inserir
    ApTemp->p[1] = ApRetorno; //recebe o filho a direita da raiz
    ApTemp->p[0] = *Ap;// recebe toda subarvore que ja existia
    *Ap = ApTemp; // enderençando nova raiz
  }
}

/*recebe o registro, qual arvore recebera esse registro, a variavel Cresceu, o registro que sera retornado,
o filho a direita do registro que sera retornado e a variavel para contabilizar as comparacoes*/
void arvoreB_Ins(Dados Reg, Apontador Ap, short *Cresceu, Dados *RegRetorno,  Apontador *ApRetorno, int *comparacoes){
  long i = 1; // Posição provavel do vetor em que novo indice sera inserido
  long j;
  Apontador ApTemp;

  /*if responsavel por criar a pagina raiz se a arvoreB estiver vazia
  e encontrar a pagina onde um novo registro sera inserido*/
  if (Ap == NULL){
    *Cresceu = TRUE;
    (*RegRetorno) = Reg;//recebe o registro que que se deseja inserir na pagina raiz
    (*ApRetorno) = NULL;//recebe o filho a direita, como a arvore esta vazia, o mesmo é igual a NULL
    (*comparacoes)++;
    return;
  }

  /*linha 85 ate a 95: parte do programa responsavel por fazer a busca dentro da arvore
  para saber se o registro que deseja-se inserir já esta presente nela*/
  while (i < Ap->n && Reg.chave > Ap->r[i-1].chave){
    i++;
    (*comparacoes)++;
  }  
  
  if (Reg.chave == Ap->r[i-1].chave){
    printf(" Erro: Registro ja esta presente\n");
    *Cresceu = FALSE;
    (*comparacoes)++;
    return;
  }

  //se a chave desejadac e menor que a atual, a posicao no vetor de registros e decrementada
  if (Reg.chave < Ap->r[i-1].chave){
    i--;
    (*comparacoes)++;
  }

  /*vai pra proxima pagina da arvore (a direita ou a esquerda, depende se a chave atende a condicao if anterior ou nao)
  verificar se o registro pode ser inserido nela*/
  arvoreB_Ins(Reg, Ap->p[i], Cresceu, RegRetorno, ApRetorno, comparacoes);

  if (!*Cresceu) return;//condicao de parada da insercao, enquanto Cresceu receber 1 (verdadeiro) a insercao continua

  //verifica se a pagina tem espaco para insercao
  if (Ap->n < MM){
    arvoreB_InsereNaPagina(Ap, *RegRetorno, *ApRetorno, comparacoes);//Chama insere na página pq tem esoaço
    *Cresceu = FALSE;
    (*comparacoes)++;
    return;
  }

  /* Overflow: Pagina tem que ser dividida */
  // Página nao tem espaço suficiente
  ApTemp = (Apontador)malloc(sizeof(Pagina));//Cria uma nova pagina
  ApTemp->n = 0;  ApTemp->p[0] = NULL; // Ela começa com zero indices e o filho a esquerda apontando para NULL

  /*determina onde o item sera inserido, se i (posicao onde sera inserido), for menor que a metade do tamnho da pagina,
  o item sera inserido na pagina que ja existe, se for maior, vai para a pagina que foi criada*/
  if (i < M + 1){
    arvoreB_InsereNaPagina(ApTemp, Ap->r[MM-1], Ap->p[MM], comparacoes);// insere o ultimo item da pagina atual na pagina temporaria 
    Ap->n--;// libera espaco na pagina atual
    arvoreB_InsereNaPagina(Ap, *RegRetorno, *ApRetorno, comparacoes);// insege o registro desejado na pagina atual
  } 
  else arvoreB_InsereNaPagina(ApTemp, *RegRetorno, *ApRetorno, comparacoes);//insere na pagina temporaria se a condicao do if não for verdadeira

  /**/
  for (j = M + 2; j <= MM; j++){
    arvoreB_InsereNaPagina(ApTemp, Ap->r[j-1], Ap->p[j], comparacoes);// insere o ultimo item da pagina atual na pagina temporaria 
  }

  Ap->n = M;  ApTemp->p[0] = Ap->p[M+1];
  *RegRetorno = Ap->r[M];  *ApRetorno = ApTemp; //transforma a pagina temporaria no filho a direita do item que foi inserido na pagina pai
}

/*recebe a pagina na qual se deseja inserir um registro, o registro que sera inserido,
o filho a direita do registro que sera inserido e uma variavel para contabilizar as comparaçoes*/
void arvoreB_InsereNaPagina(Apontador Ap, Dados Reg, Apontador ApDir, int *comparacoes){
  short NaoAchouPosicao;
  int k;

  k = Ap->n;  NaoAchouPosicao = (k > 0);

  while (NaoAchouPosicao){
    if (Reg.chave >= Ap->r[k-1].chave){
      NaoAchouPosicao = FALSE;
      (*comparacoes)++;
      break;
    }

    //troca as registros de lugar se a chave do registro que se deseja inser for menor que do registro já presente na pagina
    Ap->r[k] = Ap->r[k-1];
    Ap->p[k+1] = Ap->p[k];
    k--;
    if (k < 1){
      NaoAchouPosicao = FALSE;
      (*comparacoes)++;
    }
  }

  Ap->r[k] = Reg; 
  Ap->p[k+1] = ApDir;
  Ap->n++;
}
#ifndef GERADOR_H
#define GERADOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define CAD_D2 500
#define CAD_D3 3000

typedef struct d Componentes;

void arqOrdenado(int qtd);
void arqInverso(int qtd);
void arqRand(int qtd);

#endif
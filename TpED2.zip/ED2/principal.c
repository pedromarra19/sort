#include <stdio.h>
#include <stdlib.h>
#include "arvoreStar.h"

//#define CAD_DADOS2 500
//#define CAD_DADOS3 3000
#define M 20
#define MM  (M * 2) //Ordem -1
#define FALSE 0
#define TRUE  1

int main(){

    /*int chave;
    printf("Lanca a chave: ");
    scanf("%d",&chave);

    FILE *arq = fopen("registros.bin","rb");

    if(!pesquisa(chave, arq)){
        printf("Busca mau sucedida.\n");
    }
    else{
        printf("Chave localizada.\n");
    }
    fclose(arq);*/

    TipoChave k;
    TipoRegistro x;
    TipoApontador arvore;
    FILE *registros;

    registros = fopen("registros1.bin","rb");
        if(registros == NULL){
            printf("falha ao abrir o arquivo\n");
            return 0;
        }
        criaStar(&arvore);
        for (int i = 0; i < 20; i++){
            fread(&k, sizeof(TipoChave), 1, registros);
            fseek(registros,sizeof(TipoRegistro)-4,SEEK_CUR);
            insereStar(k,&arvore);
        }
        
        fclose(registros);
        pesquisaStar(&x,&arvore);
        
    return 0;
}